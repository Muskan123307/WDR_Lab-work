import React from 'react';

function OrderedList() {
  const items = ['Apple', 'Banana', 'Cherry', 'Date', 'Elderberry'];
  return (
    <div>
      <h3>Ordered List</h3>
      <ol>
        {items.map((item, index) => (
          <li key={index}>{item}</li>
        ))}
      </ol>
    </div>
  );
}

export default OrderedList;
