// UnorderedList.jsx
import React from 'react';

function UnorderedList() {
  const subjects = ['Math', 'Physics', 'Chemistry', 'Biology', 'English', 'History'];
  return (
    <div>
      <h3>Unordered List of Subjects</h3>
      <ul>
        {subjects.map((subject, index) => (
          <li key={index}>{subject}</li>
        ))}
      </ul>
    </div>
  );
}

export default UnorderedList;
