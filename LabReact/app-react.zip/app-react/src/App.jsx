import OrderedList from "./OrderedList.jsx";
import UnorderedList from "./UnorderedList.jsx";
function App(){
  return(
    <div>
      <OrderedList/>
      <hr />
      <UnorderedList/>
    </div>
  );
}
export default App;